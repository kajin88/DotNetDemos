﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserRegistrationApp
{
    class BusinessLogicLayer2
    {
        public static bool CreateNewUser(User newUser)
        {
            //Do something more here.
            try
            {
                newUser.CheckUser();
                return DatabaseLayer.SaveUserToDatabase(newUser);
            }
            catch(Exception ex)
            {
                //Log the exception.
                throw;
            }
        }
    }
}
