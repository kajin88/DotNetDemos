﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserRegistrationApp
{
    class DatabaseLayer
    {
        public static bool SaveUserToDatabase(User user)
        {
            if(user.Email =="abc@gmail.com")
            {
                throw new UserExistsException("This user already exists!");
            }

            //DO the Database Activity.
            return true;
        }
    }
}
