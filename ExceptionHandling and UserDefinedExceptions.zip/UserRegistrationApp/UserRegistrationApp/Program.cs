﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserRegistrationApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Your Name : ");
            string name = Console.ReadLine();
            Console.Write("Enter Your Email : ");
            string email = Console.ReadLine();

            try
            {
                bool result = BusinessLogicLayer1.CreateUser(name, email);

                if (result)
                    Console.WriteLine("\nUser created successfully!\n");
            }
            catch(FileNotFoundException fex)
            {
                Console.WriteLine("File exception occurred.");
                Console.WriteLine($"Error: {fex.StackTrace}");
            }
            catch(NullReferenceException)
            {
                Console.WriteLine("Null Ref exception occurred.");
            }
            catch(UserExistsException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            catch(Exception ex)
            {
                Console.WriteLine("Unexpected exception occurred.");
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                Console.WriteLine("We are in Finally");
            }

            Console.ReadLine();
        }
    }
}
