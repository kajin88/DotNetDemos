﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserRegistrationApp
{
    class BusinessLogicLayer1
    {
        public static bool CreateUser(string userName, string userEmail)
        {
            User user = new User(userName, userEmail);

            return BusinessLogicLayer2.CreateNewUser(user);
        }
    }
}
